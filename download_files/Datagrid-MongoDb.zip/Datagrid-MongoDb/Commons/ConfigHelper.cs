﻿using System;
using System.Xml.Linq;

namespace GigaSpaces.Examples.Datagrid.Commons
{
    public class ConfigHelper
    {
        public static void GetPartitionsFromSla(out string partitions, out string backupPerPartition)
        {
            partitions = "1";
            backupPerPartition = "1";
            try
            {
                string envPartitions = null;
                string envBackupPerPartition = null;

                XDocument xdoc = XDocument.Load("..\\..\\Deploy\\Datagrid\\sla.xml");
                if (xdoc.Root != null)
                {
                    var ns = xdoc.Root.GetDefaultNamespace();
                    var beans = xdoc.Elements(ns + "beans");
                    foreach (var bean in beans)
                    {
                        foreach (var sla in bean.Descendants())
                        {
                            envPartitions = sla.Attribute("number-of-instances").Value;
                            envBackupPerPartition = sla.Attribute("number-of-backups").Value;
                            break;
                        }
                    }
                }

                if (envPartitions != null)
                    partitions = envPartitions;
                if (envBackupPerPartition != null)
                    backupPerPartition = envBackupPerPartition;
            }

            catch (Exception )
            {
            }
            ;
        }
    }
}
