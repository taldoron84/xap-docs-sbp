﻿using System.Configuration;
using GigaSpaces.Core;
using GigaSpaces.Core.Document;
using GigaSpaces.Core.Metadata;
using System;

namespace GigaSpaces.Examples.Datagrid.Commons.Entities
{
    [SpaceClass(Persist = true)]
    public class Person
    {
        private string _id;
        private string _firstname;
        private string _lastname;
        private string _age;
        public Person(string id, string firstName, string lastName, string age)
        {
            _id = id;
            _firstname = firstName;
            _lastname = lastName;
            _age = age;
        }

        public Person()
        {

        }

        [SpaceID(AutoGenerate = false), SpaceRouting]
        public string Id
        {
            get { return _id; }
            set { _id = value; }
        }

        [SpaceIndex(Type = SpaceIndexType.Basic)]
        public string FirstName
        {
            get { return _firstname; }
            set { _firstname = value; }
        }

        [SpaceIndex(Type = SpaceIndexType.Basic)]
        public string LastName
        {
            get { return _lastname; }
            set { _lastname = value; }
        }

        [SpaceIndex(Type = SpaceIndexType.Basic)]
        public string Age
        {
            get { return _age; }
            set { _age = value; }
        }
    }

}
